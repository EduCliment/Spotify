package model;

public class Album {

    public String nombre_del_album;
    public String imagen;
    public String autor_album;
    public int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre_del_album() {
        return nombre_del_album;
    }

    public void setNombre_del_album(String nombre_del_album) {
        this.nombre_del_album = nombre_del_album;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getAutor_album() {
        return autor_album;
    }

    public void setAutor_album(String autor_album) {
        this.autor_album = autor_album;
    }
}
