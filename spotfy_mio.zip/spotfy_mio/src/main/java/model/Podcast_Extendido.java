package model;

public class Podcast_Extendido {


    public String imagen_podcast_ext;
    public String nombre_podcast_ext;

    public String getImagen_podcast_ext() {
        return imagen_podcast_ext;
    }

    public void setImagen_podcast_ext(String imagen_podcast_ext) {
        this.imagen_podcast_ext = imagen_podcast_ext;
    }

    public String getNombre_podcast_ext() {
        return nombre_podcast_ext;
    }

    public void setNombre_podcast_ext(String nombre_podcast_ext) {
        this.nombre_podcast_ext = nombre_podcast_ext;
    }

    public String getDescripcion_podcast_ext() {
        return descripcion_podcast_ext;
    }

    public void setDescripcion_podcast_ext(String descripcion_podcast_ext) {
        this.descripcion_podcast_ext = descripcion_podcast_ext;
    }

    public String descripcion_podcast_ext;

}
