package model;

public class Artista {

    public String nombre;
    public String imagen_artista;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getImagen_artista() {
        return imagen_artista;
    }

    public void setImagen_artista(String imagen_artista) {
        this.imagen_artista = imagen_artista;
    }
}
