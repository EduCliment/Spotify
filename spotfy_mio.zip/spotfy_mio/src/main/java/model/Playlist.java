package model;

public class Playlist {

    public String nombre_playlist;
    public String imagen_playlist;
    public String fecha_creacion;

    public String getNombre_playlist() {
        return nombre_playlist;
    }

    public void setNombre_playlist(String nombre_playlist) {
        this.nombre_playlist = nombre_playlist;
    }

    public String getImagen_playlist() {
        return imagen_playlist;
    }

    public void setImagen_playlist(String imagen_playlist) {
        this.imagen_playlist = imagen_playlist;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
