package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Album;
import model.Cancion;



public class Controlador_album {
    @FXML
    private ImageView imagen_album;

    @FXML
    private Label nombre_album;

    @FXML
    private Label nombre_artista;


    @FXML
    private Button corazoon;
    @FXML
    private ImageView cora_color;


    public void setData(Album album) {

        Image imagen = new Image(album.getImagen());
        imagen_album.setImage(imagen);
        nombre_album.setText(album.getNombre_del_album());
        nombre_artista.setText(album.getAutor_album());


    }

    public void anyade_fav_album(ActionEvent actionEvent) {

        System.out.println("aaa");
    }
}
