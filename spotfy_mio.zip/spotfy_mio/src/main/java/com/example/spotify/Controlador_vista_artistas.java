package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;



public class Controlador_vista_artistas implements Initializable {

    List<Artista> Artista;
    Usuario usuario = new Usuario();
    public boolean favorito_corazon = false;
    Cancion cancion = new Cancion();
    int podcaaast;

    Image corazonverde = new Image("com/example/spotify/img/ic_love_on.png");
    Image corazonblanco = new Image("com/example/spotify/img/ic_love.png");
    @FXML
    private Label autor_rep;

    @FXML
    private Button boton_fav;

    @FXML
    private VBox cacaca;

    @FXML
    private ImageView corazon;


    @FXML
    private ImageView img_reproductor;

    @FXML
    private Label nombre_cancion_rep;

    @FXML
    private SplitMenuButton nombre_usuario_vista_p;



    @FXML
    private Label segundos_totales;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        nombre_usuario_vista_p.setText(Controlador_login.id_controlador_login);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select id from usuario where username = " + '"' + nombre_usuario_vista_p.getText() + '"');
            while (rs.next()) {
                usuario.setId(rs.getInt("id"));

            }

            ResultSet rsa = stmt.executeQuery("select nombre_cancion, artista, duracion , imagen , espodcast from ultima_cancion where usuario_id = " + '"' + usuario.getId() + '"');
            while (rsa.next()) {
                nombre_cancion_rep.setText(rsa.getString("nombre_cancion"));
                autor_rep.setText(rsa.getString("artista"));
                segundos_totales.setText(rsa.getString("duracion"));
                img_reproductor.setImage(new Image(rsa.getString("imagen")));
                podcaaast = rsa.getInt("espodcast");

            }

            if (podcaaast == 1) {

                boton_fav.setVisible(false);
            } else {
                boton_fav.setVisible(true);
            }

            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
            while (sacar_id.next()) {
                cancion.setId(sacar_id.getInt("id"));

            }

            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"' );
            while (comparar_id.next()) {

                favorito_corazon = true;

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (favorito_corazon) {
            corazon.setImage(corazonverde);

        } else {
            corazon.setImage(corazonblanco);
            favorito_corazon = false;

        }



        Artista = new ArrayList<>(getArtistas());


        try {

            for (Artista lista_artistas : Artista) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("artista.fxml"));

                Pane vBox = fxmlLoader.load();

                Controlador_artista controlador_cancion = fxmlLoader.getController();
                controlador_cancion.setData(lista_artistas);

                cacaca.getChildren().add(vBox);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }



    }


    public List<Artista> getArtistas() {

        List<Artista> ls = new ArrayList();
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();


            ResultSet datos_princ = stmt.executeQuery("SELECT nombre, imagen FROM spotify.artista");


            while (datos_princ.next()) {
                String nombre = datos_princ.getString("nombre");
                String imagen_c = datos_princ.getString("imagen");

                Artista song = new Artista();
                song.setImagen_artista(imagen_c);
                song.setNombre(nombre);


                ls.add(song);

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }



        return ls;
    }





    public void Controlador_explore(ActionEvent actionEvent) {
    }
    @FXML
    void crear_playlist(MouseEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("crear_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    @FXML
    public void fav(ActionEvent actionEvent) {


        if (corazon.getImage().equals(corazonverde)) {
            System.out.println(cancion.getId());
            System.out.println(usuario.getId());
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "DELETE FROM spotify.guarda_cancion WHERE (usuario_id = " + '"' + usuario.getId() + '"' +") and (cancion_id =" + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonblanco);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (corazon.getImage().equals(corazonblanco)) {

            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "INSERT INTO guarda_cancion VALUES ( " + '"' + usuario.getId() + '"' + "," + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonverde);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }

    }

    @FXML
    void funcion_playlist(MouseEvent event) {



        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void refresh(ActionEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_artistas.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    @FXML
    void volver_inicio(ActionEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void podcast(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_podcast.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void artistas(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_artistas.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void albumes(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_albumes.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
