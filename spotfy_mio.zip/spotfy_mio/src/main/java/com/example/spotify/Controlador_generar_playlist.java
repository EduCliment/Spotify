package com.example.spotify;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Playlist;

public class Controlador_generar_playlist {


    @FXML
    private ImageView img;

    @FXML
    private Label nombre_cancion;

    @FXML
    private Label artista;



    public void setData(Playlist playlist) {


        Image imagenn = new Image(playlist.getImagen_playlist());
        img.setImage(imagenn);
        nombre_cancion.setText(playlist.getNombre_playlist());
        artista.setText(playlist.getFecha_creacion());


    }
}
