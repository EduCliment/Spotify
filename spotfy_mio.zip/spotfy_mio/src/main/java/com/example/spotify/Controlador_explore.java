package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Busqueda_rec;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Controlador_explore implements Initializable {
    @FXML
    private HBox busquedas_recientes_container;
    List<Busqueda_rec> Buscado_reciente;

    @FXML
    public ImageView corazon;
    public boolean favorita = false;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Buscado_reciente = new ArrayList<>(getBuscado_reciente());


        try {
            for (Busqueda_rec busqueda : Buscado_reciente) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("busqueda_rec.fxml"));

                VBox vBox = fxmlLoader.load();
                Controlador_Buscrec controlador_buscrec = fxmlLoader.getController();
                controlador_buscrec.setData(busqueda);

                busquedas_recientes_container.getChildren().add(vBox);

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public List<Busqueda_rec> getBuscado_reciente() {

        List<Busqueda_rec> ls = new ArrayList<>();
        Busqueda_rec cancion = new Busqueda_rec();
        cancion.setNombre("Pelele");
        cancion.setArtista("Morad");
        cancion.setCover("com/example/spotify/img/pelele.jpeg");
        ls.add(cancion);

        cancion = new Busqueda_rec();
        cancion.setNombre("No y No");
        cancion.setArtista("Morad");
        cancion.setCover("com/example/spotify/img/morad_fav.png");
        ls.add(cancion);

        cancion = new Busqueda_rec();
        cancion.setNombre("Papel - feat. Morad");
        cancion.setArtista("Rim'K, Morad");
        cancion.setCover("com/example/spotify/img/papel.jpg");
        ls.add(cancion);

        cancion = new Busqueda_rec();
        cancion.setNombre("Les Duele");
        cancion.setArtista("Morad");
        cancion.setCover("com/example/spotify/img/les_duele.jpg");
        ls.add(cancion);

        cancion = new Busqueda_rec();
        cancion.setNombre("Bobo");
        cancion.setArtista("Morad");
        cancion.setCover("com/example/spotify/img/bobo.jpg");
        ls.add(cancion);

        cancion = new Busqueda_rec();
        cancion.setNombre("Cuando Ella Sale");
        cancion.setArtista("Morad");
        cancion.setCover("com/example/spotify/img/cuando_ella_sale.jpg");
        ls.add(cancion);


        return ls;

    }







    public void Controlador_home(ActionEvent home) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
        try {
            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage) ((Node) home.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }




    }

    public void fav(ActionEvent actionEvent) {

        Image corazonverde = new Image("com/example/spotify/img/ic_love_on.png");
        Image corazonblanco = new Image("com/example/spotify/img/ic_love.png");

        if (!favorita) {

            corazon.setImage(corazonverde);
            favorita = true;
        } else {
            corazon.setImage(corazonblanco);
            favorita = false;
        }



    }
}
