package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.converter.LocalDateStringConverter;

import java.io.IOException;
import java.sql.*;
import java.time.format.DateTimeFormatter;

public class Controlador_register {

    @FXML
    private Label crearc_texto_error;

    @FXML
    private TextField crearc_user;

    int ID;

    @FXML
    private PasswordField crearc_pswd;

    @FXML
    private TextField crearc_email;

    @FXML
    private RadioButton crearc_generom;

    @FXML
    private RadioButton crearc_generof;

    @FXML
    private DatePicker crearc_fecha;

    @FXML
    private TextField crearc_pais;

    @FXML
    private TextField crearc_codigop;

    @FXML
    private Button enviar;

    @FXML
    private Button volver;

    private void realizarConsulta() {
        try {
// Establece la conexión
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
// Ejecuta la consulta

            char genero = 'A';
            if (crearc_generom.isSelected()) {
                genero = 'M';
            } else if (crearc_generof.isSelected()) {
                genero = 'F';
            }

            //changue the datepicker
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy/MM/dd");
            crearc_fecha.setConverter(new LocalDateStringConverter(formatter, null));

            //INSERT INTO
            Statement s = con.createStatement();

            s.executeUpdate("INSERT INTO usuario (username,`password`,email,genero,fecha_nacimiento,pais,codigo_postal)" +
                    "values (" + '"' + crearc_user.getText() + '"' + "," + '"' + crearc_pswd.getText() + '"' + "," + '"' + crearc_email.getText() + '"' + "," +  '"' + genero + '"' + "," + '"' +crearc_fecha.getValue() + '"' + "," + '"' + crearc_pais.getText() + '"' + "," + '"' +crearc_codigop.getText() + '"' + ");");


            ResultSet rs = s.executeQuery("SELECT id from usuario where username = " + '"' + crearc_user.getText() + '"');
            while (rs.next()) {
                ID = rs.getInt("id");

            }

            String query = "insert into free VALUES (CURDATE(), DEFAULT , " + '"' + ID + '"' + ")";
            s.executeUpdate(query);



//Cerrar la conexión
            con.close();
            crearc_texto_error.setText("Cuenta creada con exito");



        } catch (SQLIntegrityConstraintViolationException e) {
            crearc_texto_error.setText("El usuario o correo ya existe");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public void volver_login(ActionEvent volver) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("login.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage) ((Node) volver.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void enviar(ActionEvent enviar) {



        if (crearc_generof.isSelected() && crearc_generom.isSelected())
        {

            crearc_texto_error.setText("Has seleccionado ambos sexos");
        } else if (crearc_user.getText().equals("") || crearc_pswd.getText().equals("") ||
                crearc_email.getText().equals("") || !crearc_generof.isSelected() && !crearc_generom.isSelected() ||
                crearc_fecha.getValue() == null || crearc_pais.getText().equals("") || crearc_codigop.getText().equals("")) {

            crearc_texto_error.setText("Tienes datos vacíos, revisalos");

        } else if (crearc_user.getText().length() >= 45) {
            crearc_texto_error.setText("El usuario no puede tener más de 45 carácteres");
        } else if (crearc_pswd.getText().length() >= 150) {
            crearc_texto_error.setText("La contraseña no puede tener más de 150 carácteres");
        } else if (crearc_email.getText().length() >= 150) {
            crearc_texto_error.setText("El correo no puede tener más de 150 carácteres");
        } else if (crearc_pais.getText().length() >= 45) {
            crearc_texto_error.setText("El país no puede tener más de 45 carácteres");
        } else if (crearc_codigop.getText().length() >= 20) {
            crearc_texto_error.setText("El codigo postal no puede tener más de 20 carácteres");
        } else {
            realizarConsulta();
        }


    }
}