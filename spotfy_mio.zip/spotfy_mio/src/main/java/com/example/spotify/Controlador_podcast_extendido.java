package com.example.spotify;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import model.Artista;
import model.Podcast_Extendido;

public class Controlador_podcast_extendido {

    @FXML
    private ImageView imagen_podcast;

    @FXML
    private Label nombre_podcast;


    @FXML
    private Text descripcion_podcast;

    public void setData(Podcast_Extendido podcast_extendido) {

        Image imagenn = new Image(podcast_extendido.getImagen_podcast_ext());
        imagen_podcast.setImage(imagenn);
        nombre_podcast.setText(podcast_extendido.getNombre_podcast_ext());
        descripcion_podcast.setText(podcast_extendido.getDescripcion_podcast_ext());

    }
}
