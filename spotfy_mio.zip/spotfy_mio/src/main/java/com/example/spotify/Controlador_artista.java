package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Album;
import model.Artista;


public class Controlador_artista {
    @FXML
    private ImageView imagen;

    @FXML
    private Label nombre;


    public void setData(Artista artista) {

        Image imagenn = new Image(artista.getImagen_artista());
        imagen.setImage(imagenn);
        nombre.setText(artista.getNombre());


    }

}
