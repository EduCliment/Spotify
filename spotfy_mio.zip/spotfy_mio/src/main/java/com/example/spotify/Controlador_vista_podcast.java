package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Cancion;
import model.Podcast;
import model.Podcast_Extendido;
import model.Usuario;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Controlador_vista_podcast implements Initializable {

    @FXML
    private Label autor_rep;
    List<Podcast_Extendido> podcasts;
    @FXML
    private Button boton_fav;

    @FXML
    private VBox cacaca;

    @FXML
    private ImageView corazon;

    @FXML
    private Button explorer;

    @FXML
    private ImageView img_reproductor;

    @FXML
    private Label nombre_cancion_rep;

    @FXML
    private SplitMenuButton nombre_usuario_vista_p;

    @FXML
    private HBox nueva_playlist;

    public String nombre_prueba;



    public boolean favorito_corazon = false;

    String ruta_imagen;


    Usuario usuario = new Usuario();
    Cancion cancion = new Cancion();

    int podcaaast;

    Image corazonverde = new Image("com/example/spotify/img/ic_love_on.png");
    Image corazonblanco = new Image("com/example/spotify/img/ic_love.png");
    @FXML
    private Label segundos_totales;

    @FXML
    void Controlador_explore(ActionEvent event) {

    }

    @FXML
    void crear_playlist(MouseEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("crear_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    @FXML
    public void fav(ActionEvent actionEvent) {


        if (corazon.getImage().equals(corazonverde)) {
            System.out.println(cancion.getId());
            System.out.println(usuario.getId());
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "DELETE FROM spotify.guarda_cancion WHERE (usuario_id = " + '"' + usuario.getId() + '"' +") and (cancion_id =" + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonblanco);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (corazon.getImage().equals(corazonblanco)) {

            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "INSERT INTO guarda_cancion VALUES ( " + '"' + usuario.getId() + '"' + "," + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonverde);
                con.close();
                System.out.println("caca");
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }

    }

    @FXML
    void funcion_playlist(MouseEvent event) {



        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void refresh(ActionEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_podcast.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void volver_inicio(ActionEvent event) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        nombre_usuario_vista_p.setText(Controlador_login.id_controlador_login);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select id from usuario where username = " + '"' + nombre_usuario_vista_p.getText() + '"');
            while (rs.next()) {
                usuario.setId(rs.getInt("id"));

            }

            ResultSet rsa = stmt.executeQuery("select nombre_cancion, artista, duracion , imagen , espodcast from ultima_cancion where usuario_id = " + '"' + usuario.getId() + '"');
            while (rsa.next()) {
                nombre_cancion_rep.setText(rsa.getString("nombre_cancion"));
                autor_rep.setText(rsa.getString("artista"));
                segundos_totales.setText(rsa.getString("duracion"));
                img_reproductor.setImage(new Image(rsa.getString("imagen")));
                podcaaast = rsa.getInt("espodcast");

            }

            if (podcaaast == 1) {

                boton_fav.setVisible(false);
            } else {
                boton_fav.setVisible(true);
            }

            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
            while (sacar_id.next()) {
                cancion.setId(sacar_id.getInt("id"));

            }

            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"');
            while (comparar_id.next()) {

                favorito_corazon = true;

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (favorito_corazon) {
            corazon.setImage(corazonverde);

        } else {
            corazon.setImage(corazonblanco);
            favorito_corazon = false;

        }

        podcasts = new ArrayList<>(getPodcast());

        try {
            for (Podcast_Extendido podcast_extendido : podcasts) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("podcast_expandido.fxml"));

                Pane vBox = fxmlLoader.load();
                vBox.onMouseClickedProperty().set(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {

                        boton_fav.setVisible(false);
                        nombre_cancion_rep.setText(podcast_extendido.getNombre_podcast_ext());
                        autor_rep.setText(podcast_extendido.getDescripcion_podcast_ext());
                        nombre_prueba = nombre_cancion_rep.getText();
                        try {
                            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                            Statement stmt = con.createStatement();
                            ResultSet rs = stmt.executeQuery("select imagen from podcast where titulo =" + '"' + nombre_prueba + '"');

                            while (rs.next()) {
                                ruta_imagen = rs.getString("imagen");
                                Image imagen_rep = new Image(ruta_imagen);
                                img_reproductor.setImage(imagen_rep);
                            }

                            String delete = "DELETE FROM ultima_cancion where usuario_id  =" + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(delete);


                            String insertar = "insert into ultima_cancion (nombre_cancion,artista,duracion,imagen,usuario_id, espodcast ) VALUES (" + '"' + podcast_extendido.getNombre_podcast_ext() + '"' + "," + '"' + podcast_extendido.getDescripcion_podcast_ext() + '"' + ", DEFAULT ," + '"' + ruta_imagen + '"' + "," + '"' + usuario.getId() + '"' + ", DEFAULT" + ")";
                            stmt.executeUpdate(insertar);

                            String update = "update ultima_cancion set duracion =" + '"' + segundos_totales.getText() + '"' + ", espodcast = 1 where usuario_id = " + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(update);  // Hago este UPDATE porque lo de arriba se bugea IDK WHY pero pone numeros randoms en la columna duracion
                            System.out.println(segundos_totales.getText());


                            con.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                });
                Controlador_podcast_extendido podcastController = fxmlLoader.getController();
                podcastController.setData(podcast_extendido);
                cacaca.getChildren().add(vBox);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        }

    private List<Podcast_Extendido> getPodcast() {
        List<Podcast_Extendido> ls = new ArrayList<>();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select podcast.titulo ,podcast.imagen,podcast.descripcion from podcast_usuario pu inner join podcast on podcast.id=pu.podcast_id inner join usuario on usuario.id=pu.usuario_id group by podcast.titulo");
            while (rs.next()) {

                String titulo = rs.getString("titulo");
                String imagen = rs.getString("imagen");
                String descripcion = rs.getString("descripcion");
                Podcast_Extendido podcast = new Podcast_Extendido();
                podcast.setNombre_podcast_ext(titulo);
                podcast.setImagen_podcast_ext(imagen);
                podcast.setDescripcion_podcast_ext(descripcion);
                ls.add(podcast);
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }




        return ls;
    }

    public void albumes(MouseEvent mouseEvent) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_albumes.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void artista(MouseEvent mouseEvent) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_artistas.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
