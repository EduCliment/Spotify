package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Cancion;
import model.Podcast;
import model.Usuario;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.*;




public class Controller implements Initializable {






    @FXML
    private HBox PodcastContainer;
    @FXML
    private HBox ParaTiContainer;

    public boolean favorito_corazon = false;
    public boolean soypremium = true;

    String ruta_imagen;

   int podcaaast;




    @FXML
    public HBox favoriteContainer;
    List<Podcast> podcasts;
    List<Cancion> Favoritas;
    List<Cancion> Parati;

    Usuario usuario = new Usuario();
    Cancion cancion = new Cancion();

    public String nombre_prueba;
    @FXML
    Button explorer;

    @FXML
    private SplitMenuButton nombre_usuario_vista_p;
    @FXML
    public ImageView corazon;
    @FXML
    private Button boton_fav;


    @FXML
    private Button premium_aviso;

    @FXML
    private Label nombre_cancion_rep;

    @FXML
    private Label autor_rep;

    @FXML
    private ImageView img_reproductor;

    @FXML
    private Label segundos_totales;


    Image corazonverde = new Image("com/example/spotify/img/ic_love_on.png");
    Image corazonblanco = new Image("com/example/spotify/img/ic_love.png");


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {




        nombre_usuario_vista_p.setText(Controlador_login.id_controlador_login);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select id from usuario where username = " + '"' + nombre_usuario_vista_p.getText() + '"');
            while (rs.next()) {
                usuario.setId(rs.getInt("id"));

            }
            /* --------------------------------------- */

            ResultSet rsa = stmt.executeQuery("select nombre_cancion, artista, duracion , imagen , espodcast from ultima_cancion where usuario_id = " + '"' + usuario.getId() + '"');
            while (rsa.next()) {
                nombre_cancion_rep.setText(rsa.getString("nombre_cancion"));
                autor_rep.setText(rsa.getString("artista"));
                segundos_totales.setText(rsa.getString("duracion"));
                img_reproductor.setImage(new Image(rsa.getString("imagen")));
                podcaaast = rsa.getInt("espodcast");

            }

            if (podcaaast == 1) {

                boton_fav.setVisible(false);
            } else {
                boton_fav.setVisible(true);
            }

            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
            while (sacar_id.next()) {
                cancion.setId(sacar_id.getInt("id"));

            }

            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"' );
            while (comparar_id.next()) {

                favorito_corazon = true;

            }


            ResultSet espremium = stmt.executeQuery("SELECT * FROM spotify.free where usuario_id = " + '"' + usuario.getId() + '"');
            while (espremium.next()) {
                soypremium = false;
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        if (favorito_corazon) {
            corazon.setImage(corazonverde);

        } else {
            corazon.setImage(corazonblanco);
            favorito_corazon = false;

        }


        if (soypremium) {
            premium_aviso.setText("Cuenta Premium");
            premium_aviso.setStyle("-fx-text-fill: #1ED760 ; -fx-border-color: #1ED760");
        }

        podcasts = new ArrayList<>(getPodcast());
        Favoritas = new ArrayList<>(getFavoritas());
        Parati = new ArrayList<>(getParati());


        try {
            for (Podcast podcast : podcasts) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("podcast.fxml"));

                VBox vBox = fxmlLoader.load();
                vBox.onMouseClickedProperty().set(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {

                        boton_fav.setVisible(false);
                        nombre_cancion_rep.setText(podcast.getTitulo());
                        autor_rep.setText(podcast.getDescripcion());
                        nombre_prueba = nombre_cancion_rep.getText();
                        try {
                            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                            Statement stmt = con.createStatement();
                            ResultSet rs = stmt.executeQuery("select imagen from podcast where titulo =" + '"' + nombre_prueba + '"');

                            while (rs.next()) {
                                ruta_imagen = rs.getString("imagen");
                                Image imagen_rep = new Image(ruta_imagen);
                                img_reproductor.setImage(imagen_rep);
                            }

                            String delete = "DELETE FROM ultima_cancion where usuario_id  =" + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(delete);


                            String insertar = "insert into ultima_cancion (nombre_cancion,artista,duracion,imagen,usuario_id, espodcast ) VALUES ("+ '"' + podcast.getTitulo() + '"' + "," + '"' + podcast.getDescripcion() + '"' + ", DEFAULT ," + '"' + ruta_imagen + '"' + "," + '"' + usuario.getId() + '"' + ", DEFAULT" + ")";
                            stmt.executeUpdate(insertar);

                            String update = "update ultima_cancion set duracion =" + '"' + segundos_totales.getText() + '"' + ", espodcast = 1 where usuario_id = " + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(update);  // Hago este UPDATE porque lo de arriba se bugea IDK WHY pero pone numeros randoms en la columna duracion
                            System.out.println(segundos_totales.getText());



                            con.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                });
                PodcastController podcastController = fxmlLoader.getController();
                podcastController.setDatos(podcast);
                PodcastContainer.getChildren().add(vBox);
            }




            for (Cancion lista_cancion : Favoritas) {


                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("cancion.fxml"));
                VBox vBox = fxmlLoader.load();
                vBox.onMouseClickedProperty().set(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {

                        boton_fav.setVisible(true);
                        favorito_corazon = false; // RESETEAMOS LA VARIABLE PARA EVITAR PROBLEMAS CON EL CORA

                        nombre_cancion_rep.setText(lista_cancion.getNombre());
                        autor_rep.setText(lista_cancion.getArtista());
                        Image imagen_rep = new Image(lista_cancion.getCover());
                        img_reproductor.setImage(imagen_rep);

                        try {
                            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                            Statement stmt = con.createStatement();

                            /* SEGUNDOS AL REPRODUCTOR */
                            ResultSet rs = stmt.executeQuery("select duracion from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
                            while (rs.next()) {
                                int duracion_cancion = rs.getInt("duracion");
                                String caca;
                                int hor;
                                int min;
                                int seg;
                                hor=duracion_cancion/3600;
                                min=(duracion_cancion-(3600*hor))/60;
                                seg=duracion_cancion-((hor*3600)+(min*60));
                                if (seg<10) {  // Añadimos un 0 para que se vea fachero (es menor a 10 y se ve caca)
                                    caca = (min+":0"+seg);
                                    segundos_totales.setText(caca);
                                } else {
                                    caca = (min+":"+seg);
                                    segundos_totales.setText(caca);
                                }
                            }

                            /* ------------------------------------------ */

                            /* SACAR ID CANCION*/
                            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
                            while (sacar_id.next()) {
                                cancion.setId(sacar_id.getInt("id"));
                            }
                            /* SI ES FAVORITA CORA VERDE */
                            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"' );
                            while (comparar_id.next()) {
                                favorito_corazon = true;
                            }

                            if (favorito_corazon) {
                                corazon.setImage(corazonverde);
                            } else {
                                corazon.setImage(corazonblanco);
                                favorito_corazon = false;
                            }

                            /* ------------------------------------------ */

                            /* ULTIMA CANCION*/
                            String delete = "DELETE FROM ultima_cancion where usuario_id  =" + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(delete);


                            String insertar = "insert into ultima_cancion (nombre_cancion,artista,duracion,imagen,usuario_id ) VALUES ("+ '"' + lista_cancion.getNombre() + '"' + "," + '"' + lista_cancion.getArtista() + '"' + ", DEFAULT ," + '"' + lista_cancion.getCover() + '"' + "," + '"' + usuario.getId() + '"' + ")";
                            stmt.executeUpdate(insertar);

                            String update = "update ultima_cancion set duracion =" + '"' + segundos_totales.getText() + '"' +  ", espodcast = 0 where usuario_id = " + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(update);  // Hago este UPDATE porque lo de arriba se bugea IDK WHY pero pone numeros randoms en la columna duracion
                            System.out.println(segundos_totales.getText());

                            con.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                });
                Controlador_Cancion controlador_cancion = fxmlLoader.getController();
                controlador_cancion.setData(lista_cancion);
                favoriteContainer.getChildren().add(vBox);
            }

            for (Cancion lista_cancion : Parati) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("cancion.fxml"));

                VBox vBox = fxmlLoader.load();
                vBox.onMouseClickedProperty().set(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {

                        boton_fav.setVisible(true);
                        favorito_corazon = false; // RESETEAMOS LA VARIABLE PARA EVITAR PROBLEMAS CON EL CORA

                        nombre_cancion_rep.setText(lista_cancion.getNombre());
                        autor_rep.setText(lista_cancion.getArtista());
                        Image imagen_rep = new Image(lista_cancion.getCover());
                        img_reproductor.setImage(imagen_rep);

                        try {                  // Segundos al reproductor
                            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                            Statement stmt = con.createStatement();
                            ResultSet rs = stmt.executeQuery("select duracion from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
                            while (rs.next()) {
                                int duracion_cancion = rs.getInt("duracion");
                                String caca;
                                int hor;
                                int min;
                                int seg;
                                hor=duracion_cancion/3600;
                                min=(duracion_cancion-(3600*hor))/60;
                                seg=duracion_cancion-((hor*3600)+(min*60));
                                if (seg<10) {  // Añadimos un 0 para que se vea fachero (es menor a 10 y se ve caca)
                                    caca = (min+":0"+seg);
                                    segundos_totales.setText(caca);
                                } else {
                                    caca = (min+":"+seg);
                                    segundos_totales.setText(caca);
                                }
                            }

                            /* ------------------------------------------ */

                            /* SACAR ID CANCION*/
                            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
                            while (sacar_id.next()) {
                                cancion.setId(sacar_id.getInt("id"));
                            }

                            /* ------------------------------------------ */

                            /* SI ES FAVORITA CORA VERDE */
                            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"' );
                            while (comparar_id.next()) {
                                favorito_corazon = true;
                            }

                            if (favorito_corazon) {
                                corazon.setImage(corazonverde);
                            } else {
                                corazon.setImage(corazonblanco);
                                favorito_corazon = false;
                            }

                            /* ------------------------------------------ */

                            /* ULTIMA CANCION*/
                            String delete = "DELETE FROM ultima_cancion where usuario_id  =" + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(delete);

                            String insertar = "insert into ultima_cancion (nombre_cancion,artista,duracion,imagen,usuario_id ) VALUES ("+ '"' + lista_cancion.getNombre() + '"' + "," + '"' + lista_cancion.getArtista() + '"' + ", DEFAULT ," + '"' + lista_cancion.getCover() + '"' + "," + '"' + usuario.getId() + '"' + ")";
                            stmt.executeUpdate(insertar);

                            String update = "update ultima_cancion set duracion =" + '"' + segundos_totales.getText() + '"' +  ", espodcast = 0 where usuario_id = " + '"' + usuario.getId() + '"';
                            stmt.executeUpdate(update);
                            System.out.println(segundos_totales.getText());   // Hago esto porque lo de arriba se bugea IDK WHY pero pone numeros randoms en la columna duracion


                            con.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }  // Segundos al reproductor



                    }
                });
                Controlador_Cancion controlador_cancion = fxmlLoader.getController();
                controlador_cancion.setData(lista_cancion);

                ParaTiContainer.getChildren().add(vBox);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private List<Podcast> getPodcast() {
        List<Podcast> ls = new ArrayList<>();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select podcast.titulo ,podcast.imagen,podcast.descripcion from podcast_usuario pu inner join podcast on podcast.id=pu.podcast_id inner join usuario on usuario.id=pu.usuario_id where pu.usuario_id =" + '"' + usuario.getId() + '"');
            while (rs.next()) {

                String titulo = rs.getString("titulo");
                String imagen = rs.getString("imagen");
                String descripcion = rs.getString("descripcion");
                Podcast podcast = new Podcast();
                podcast.setTitulo(titulo);
                podcast.setImagen(imagen);
                podcast.setDescripcion(descripcion);
                ls.add(podcast);
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ls;
    }

    public List<Cancion> getFavoritas() {

        List<Cancion> ls = new ArrayList();
        try {
// Establece la conexión
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
// Ejecuta la consulta
            Statement stmt = con.createStatement();

            ResultSet titulo = stmt.executeQuery("select cancion.titulo, album.imagen, artista.nombre\n" +
                    "from guarda_cancion gc\n" +
                    "inner join cancion on cancion.id=gc.cancion_id\n" +
                    "inner join usuario on usuario.id=gc.usuario_id\n" +
                    "inner join album on album.id=cancion.album_id\n" +
                    "inner join artista on artista.id=album.artista_id\n" +
                    "where usuario.id =" + '"' + usuario.getId() + '"');



// Procesa los resultados
            while (titulo.next()) {
                String titulo_c = titulo.getString("cancion.titulo");

                String artista_c = titulo.getString("artista.nombre");
                String imagen_c = titulo.getString("album.imagen");


                Cancion song = new Cancion();
                song.setNombre(titulo_c);
                song.setArtista(artista_c);
                song.setCover(imagen_c);
                ls.add(song);
            }
//Cerrar la conexión
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return ls;
    }


    public List<Cancion> getParati() {

        List<Cancion> ls = new ArrayList();
        try {
// Establece la conexión
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
// Ejecuta la consulta
            Statement stmt = con.createStatement();

            ResultSet titulo = stmt.executeQuery("select cancion.id , cancion.titulo, album.imagen, artista.nombre\n" +
                    "from guarda_cancion gc\n" +
                    "inner join cancion on cancion.id=gc.cancion_id\n" +
                    "inner join usuario on usuario.id=gc.usuario_id\n" +
                    "inner join album on album.id=cancion.album_id\n" +
                    "inner join artista on artista.id=album.artista_id\n" +
                    "where  cancion_id not in (select cancion_id from guarda_cancion where usuario_id = " + '"' + usuario.getId() + '"' +") " +
                    "group by titulo limit 10;\n");



// Procesa los resultados
            while (titulo.next()) {
                String titulo_c = titulo.getString("cancion.titulo");

                String artista_c = titulo.getString("artista.nombre");
                String imagen_c = titulo.getString("album.imagen");


                Cancion song = new Cancion();
                song.setNombre(titulo_c);
                song.setArtista(artista_c);
                song.setCover(imagen_c);
                ls.add(song);
            }
//Cerrar la conexión
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        return ls;
    }

    public void Controlador_explore(ActionEvent explorer) {




    }




    public void fav(ActionEvent actionEvent) {




       if (corazon.getImage().equals(corazonverde)) {
            System.out.println(cancion.getId());
            System.out.println(usuario.getId());
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "DELETE FROM spotify.guarda_cancion WHERE (usuario_id = " + '"' + usuario.getId() + '"' +") and (cancion_id =" + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonblanco);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (corazon.getImage().equals(corazonblanco)) {

            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "INSERT INTO guarda_cancion VALUES ( " + '"' + usuario.getId() + '"' + "," + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonverde);
                con.close();
                System.out.println("caca");
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }

    }


    public void refresh(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void funcion_playlist(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void crear_playlist(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("crear_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void vista_albumes(MouseEvent mouseEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_albumes.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    public void artistas(MouseEvent mouseEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_artistas.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    public void podcast(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_podcast.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
