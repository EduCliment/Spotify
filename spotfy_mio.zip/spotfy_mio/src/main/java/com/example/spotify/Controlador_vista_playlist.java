package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Cancion;
import model.Playlist;
import model.Usuario;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.*;



public class Controlador_vista_playlist implements Initializable {


    public boolean favorito_corazon = false;
    // boolean soypodcast = true;




    List<Playlist> Playlists;

    Usuario usuario = new Usuario();
    Cancion cancion = new Cancion();


    int podcaaast;
    @FXML
    Button explorer;

    @FXML
    private SplitMenuButton nombre_usuario_vista_p;
    @FXML
    public ImageView corazon;
    @FXML
    private Button boton_fav;
    @FXML
    private VBox cacaca;

    @FXML
    private Label nombre_cancion_rep;

    @FXML
    private Label autor_rep;

    @FXML
    private ImageView img_reproductor;

    @FXML
    private Label segundos_totales;

    Image corazonverde = new Image("com/example/spotify/img/ic_love_on.png");
    Image corazonblanco = new Image("com/example/spotify/img/ic_love.png");






    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        nombre_usuario_vista_p.setText(Controlador_login.id_controlador_login);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("select id from usuario where username = " + '"' + nombre_usuario_vista_p.getText() + '"');
            while (rs.next()) {
                usuario.setId(rs.getInt("id"));

            }

            ResultSet rsa = stmt.executeQuery("select nombre_cancion, artista, duracion , imagen , espodcast from ultima_cancion where usuario_id = " + '"' + usuario.getId() + '"');
            while (rsa.next()) {
                nombre_cancion_rep.setText(rsa.getString("nombre_cancion"));
                autor_rep.setText(rsa.getString("artista"));
                segundos_totales.setText(rsa.getString("duracion"));
                img_reproductor.setImage(new Image(rsa.getString("imagen")));
                podcaaast = rsa.getInt("espodcast");

            }

            if (podcaaast == 1) {

                boton_fav.setVisible(false);
            } else {
                boton_fav.setVisible(true);
            }

            ResultSet sacar_id = stmt.executeQuery("select id from cancion where titulo =" + '"' + nombre_cancion_rep.getText() + '"');
            while (sacar_id.next()) {
                cancion.setId(sacar_id.getInt("id"));

            }

            ResultSet comparar_id = stmt.executeQuery("select usuario_id, cancion_id from guarda_cancion where usuario_id =" + '"' + usuario.getId() + '"' + "and cancion_id = " + '"' + cancion.getId() + '"' );
            while (comparar_id.next()) {

                favorito_corazon = true;

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (favorito_corazon) {
            corazon.setImage(corazonverde);

        } else {
            corazon.setImage(corazonblanco);
            favorito_corazon = false;

        }



        Playlists = new ArrayList<>(getPlaylists());


        try {

            for (Playlist lista_cancion : Playlists) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("playlist.fxml"));

                BorderPane vBox = fxmlLoader.load();

                Controlador_generar_playlist controlador_cancion = fxmlLoader.getController();
                controlador_cancion.setData(lista_cancion);

                cacaca.getChildren().add(vBox);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }



    }


    public List<Playlist> getPlaylists() {

        List<Playlist> ls = new ArrayList();
        try {
// Establece la conexión
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");
// Ejecuta la consulta
            Statement stmt = con.createStatement();

            ResultSet titulo = stmt.executeQuery("SELECT titulo, fecha_creacion FROM spotify.playlist where usuario_id =" + '"' + usuario.getId() + '"');



// Procesa los resultados
            while (titulo.next()) {
                String titulo_c = titulo.getString("titulo");

                String artista_c = titulo.getString("fecha_creacion");
                //String imagen_c = titulo.getString("album.imagen");


                Playlist song = new Playlist();
                song.setNombre_playlist(titulo_c);
                song.setFecha_creacion(artista_c);
                song.setImagen_playlist("com/example/spotify/img/playlist.png");
                ls.add(song);
            }
//Cerrar la conexión
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }



        return ls;
    }



    public void Controlador_explore(ActionEvent actionEvent) {



    }

    public void funcion_playlist(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void refresh(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void fav(ActionEvent actionEvent) {


        if (corazon.getImage().equals(corazonverde)) {
            System.out.println(cancion.getId());
            System.out.println(usuario.getId());
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "DELETE FROM spotify.guarda_cancion WHERE (usuario_id = " + '"' + usuario.getId() + '"' +") and (cancion_id =" + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonblanco);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (corazon.getImage().equals(corazonblanco)) {

            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                        "dbrootpass");
                Statement stmt = con.createStatement();
                String query = "INSERT INTO guarda_cancion VALUES ( " + '"' + usuario.getId() + '"' + "," + '"' +   cancion.getId() + '"' + ")";
                stmt.executeUpdate(query);
                corazon.setImage(corazonverde);
                con.close();
                System.out.println("caca");
            } catch (SQLException e) {
                e.printStackTrace();
            }


        }

    }


    public void volver_inicio(ActionEvent actionEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void crear_playlist(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("crear_playlist.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void podcast(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_podcast.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void artista(MouseEvent mouseEvent) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_artistas.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void album(MouseEvent mouseEvent) {


        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("vista_albumes.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
