package com.example.spotify;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Cancion;
import model.Playlist;

public class Controlador_Cancion {

    public static String cancion_aux = "No has seleccionao cancion";
    @FXML
    private ImageView img;

    @FXML
    private Label nombre_cancion;

    @FXML
    private Label artista;

    public void setData(Cancion cancion) {

        Image imagen = new Image(cancion.getCover());
        img.setImage(imagen);
        nombre_cancion.setText(cancion.getNombre());
        artista.setText(cancion.getArtista());

    }
}
