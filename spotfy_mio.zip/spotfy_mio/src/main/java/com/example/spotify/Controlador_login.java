package com.example.spotify;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import model.Usuario;




public class Controlador_login {
    boolean autorizado;
    public int id_usuario;
    public static String id_controlador_login;


    public String hola;
    @FXML
    public TextField user;

    @FXML
    public PasswordField pswd;

    @FXML
    private Label texto_error;

    @FXML
    private Button crear_cuenta;
    Usuario caca = new Usuario();

    @Override
    public String toString() {
        return "Controlador_login{" +
                "user=" + user +
                '}';
    }

    public TextField getUser() {
        return user;
    }

    public void setUser(TextField user) {
        this.user = user;
    }

    public PasswordField getPswd() {
        return pswd;
    }

    public void setPswd(PasswordField pswd) {
        this.pswd = pswd;
    }

    public Label getTexto_error() {
        return texto_error;
    }

    public void setTexto_error(Label texto_error) {
        this.texto_error = texto_error;
    }



    private void realizarConsulta() {


        try {

            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:33006/spotify", "root",
                    "dbrootpass");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT username,password FROM usuario");

            while (rs.next()) {
                String usernameC = rs.getString("username");
                String passwordC = rs.getString("password");
                if (user.getText().equals(usernameC) && pswd.getText().equals(passwordC)){

                    id_controlador_login = user.getText();
                    autorizado=true;
                    break;
                }else{
                    autorizado=false;
                }

            }
//Cerrar la conexión
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public void entrar(ActionEvent entrar_bt) {


        realizarConsulta();

        if(user.getText().equals("") || pswd.getText().equals("")){

            texto_error.setText("Has introducido datos vacíos");
        } else if (!autorizado) {

            texto_error.setText("Has introducido datos erroneos");
            pswd.setText("");
            user.setText("");

        } else {

            // ENTRAMOS A SPOTIFY
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("spotify.fxml"));
            try {

                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                Stage stage;
                stage = (Stage)((Node)entrar_bt.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
                stage.setScene(scene);
                stage.show();


            } catch (IOException e) {
                e.printStackTrace();
            }




        }


    }

    public void crear_cuenta(ActionEvent crear_cuenta) {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("register.fxml"));
        try {

            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            Stage stage;
            stage = (Stage)((Node)crear_cuenta.getSource()).getScene().getWindow(); // explorer es el ActionEvent del botón (Sale arriba)
            stage.setScene(scene);
            stage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
