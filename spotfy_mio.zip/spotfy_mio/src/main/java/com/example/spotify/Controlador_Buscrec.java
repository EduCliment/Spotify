package com.example.spotify;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Busqueda_rec;
import model.Cancion;

public class Controlador_Buscrec {

    @FXML
    private Button cerrar_busc;

    @FXML
    private ImageView img;

    @FXML
    private Label nombre_cancion;

    @FXML
    private Label artista;


    public void setData(Busqueda_rec busqueda) {

        Image imagen = new Image(busqueda.getCover());
        img.setImage(imagen);
        nombre_cancion.setText(busqueda.getNombre());
        artista.setText(busqueda.getArtista());

    }


    public void cerrar_busc(ActionEvent cerrar_busc) {


    nombre_cancion.setText("Me borro");

    }
}
